import React from 'react';
import ReactDOM from 'react-dom';
import Clock from './clock';
import Tabs from './tabs';



const panes = [
  {title: 'one', content: 'I am the first'},
  {title: 'two', content: 'Second pane here'},
  {title: 'three', content: 'Third pane here'}
];


document.addEventListener("DOMContentLoaded", () => {
  console.log("page loading");
  const root = document.getElementById('root');
  ReactDOM.render(
    <div>
      <Clock />
      <Tabs panes = {panes} />
    </div>
    , root);
});
