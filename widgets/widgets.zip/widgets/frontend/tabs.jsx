import React from 'react';
import ReactDOM from 'react-dom';



class Tabs extends React.Component {

  


  render() {



  }

}


export default Tabs;
