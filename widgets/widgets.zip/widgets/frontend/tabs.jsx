import React from 'react';
import ReactDOM from 'react-dom';



class Tabs extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      tabIndex: 0
    };

    this.handleChangeTabIndex = this.handleChangeTabIndex.bind(this);
  }

  handleChangeTabIndex(e, i) {
    e.preventDefault();
    this.setState({
      tabIndex: i,
    });
  }

  render() {
    const panes = this.props.panes;
    return(
      <div>
        <ul>
          {panes.map( (pane, index) =>
            <li onClick={e => this.handleChangeTabIndex(e, index)}>
              <h1>{pane.title}</h1>
            </li>
          )}
        </ul>
        <article>{panes[this.state.tabIndex].content}</article>
      </div>
    );
  }
}

export default Tabs;
