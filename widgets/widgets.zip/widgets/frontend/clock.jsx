import React from 'react';
import ReactDOM from 'react-dom';

class Clock extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      time: new Date()
    };


    this.tick = this.tick.bind(this);
  }


  render() {
    let currentTime = this.parseTime();
    let currentDate = this.parseDate();

    return(
      <div className="clock">

        <h2 className="clockTime">Time:           {currentTime}</h2>
        <h2 className="clockDate">Date:           {currentDate}</h2>
      </div>
    );
  }

  parseTime() {
    let date = this.state.time;
    let hours = date.getHours();
    let minutes = date.getMinutes();
    let seconds = date.getSeconds();
    let amPm = hours < 12 ? "am" : "pm";

    hours = hours <= 12 ? hours : hours % 12;
    minutes = minutes < 10 ? `0${minutes}` : minutes;
    seconds = seconds < 10 ? `0${seconds}` : seconds;

    return `${hours}:${minutes}:${seconds} ${amPm}`;
  }




  parseDate() {
    let dayNames=new Array(7);
    dayNames[0]="Sunday";
    dayNames[1]="Monday";
    dayNames[2]="Tuesday";
    dayNames[3]="Wednesday";
    dayNames[4]="Thursday";
    dayNames[5]="Friday";
    dayNames[6]="Saturday";

    let monthNames = new Array(12);
    monthNames[0] = "January";
    monthNames[1] = "February";
    monthNames[2] = "March";
    monthNames[3] = "April";
    monthNames[4] = "May";
    monthNames[5] = "June";
    monthNames[6] = "July";
    monthNames[7] = "August";
    monthNames[8] = "September";
    monthNames[9] = "October";
    monthNames[10] = "November";
    monthNames[11] = "December";

    let date = this.state.time;
    let dayName = dayNames[date.getDay()];
    let dayNum = date.getDate();
    let monthName = monthNames[date.getMonth()];
    let year = date.getFullYear();


    return `${dayName}, ${monthName} ${dayNum} ${year}`;
  }


  tick() {
    this.setState({time: new Date()});
  }


  componentDidMount(){
    setInterval(this.tick, 1000);
  }





}


export default Clock;
